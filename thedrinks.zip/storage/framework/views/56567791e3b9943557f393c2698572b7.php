<?php if(session('success')): ?>
    <div class="d-flex alert-container mt-3">

        <div class="alert-content mx-auto">

            <p class="alert-text">
                <?php echo e(session('success')); ?>

            </p>

            <div class="alert-bar" style="background-color: #38B6FF;"></div>
        </div>

    </div>
    <?php 
        session()->forget('success');
    ?>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="d-flex alert-container mt-3">

        <div class="alert-content alert-error mx-auto">

            <p class="alert-text ps-3 pe-3">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>

            <div class="alert-bar" style="background-color: #F009;"></div>
        </div>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="d-flex alert-container mt-3">

        <div class="alert-content alert-error mx-auto">

            <p class="alert-text ps-3 pe-3">
                <?php echo e(session('error')); ?>

            </p>

            <div class="alert-bar" style="background-color: #F009;"></div>
        </div>

    </div>
<?php endif; ?>

<script>
    //FUNÇÃO FADEOUT DOS ALERTS
    setTimeout(() => {
        $('.alert-content').fadeOut('slow')
    }, 3000);
</script><?php /**PATH /var/www/html/thedrinks/resources/views////inc/alerts.blade.php ENDPATH**/ ?>