<?php $__env->startSection('title', 'Admin | The Drinks'); ?>

<?php $__env->startSection('content'); ?>

<div class="row mt-5">
  <div class="col-12">
    <div class="d-flex">
      <h2 class="text-center">Drinks</h2>
      <button class="btn btn-cdx ms-auto me-0" data-bs-toggle="modal" data-bs-target="#newDrinkModal"><span>Novo</span></button>
    </div>
    <div class="table-responsive mt-4">
      <small class="float-end" style="color: #DCDC">Drinks cadastrados: <?php echo e(count($drinks)); ?></small>
      <table class="table table-light table-striped align-middle">
        <thead class="table-dark">
          <tr>
            <th scope="col" width="10%">#</th>
            <th scope="col" width="40%">Nome</th>
            <th scope="col" width="40%">Categorias</th>
            <th scope="col" width="10%" colspan="2">Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>
              <img src="/images/drinks/<?php echo e($drink->photo); ?>" alt="<?php echo e($drink->name); ?>" width="50">
            </td>
            <td>
              <?php echo e($drink->name); ?>

            </td>
            <td>
              <?php $__currentLoopData = $drink->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                [<?php echo e($category->category); ?>]
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </td>
            <td><button class="btn-update"><i class="fa-solid fa-pen"></i></button></td>
            <td><i class="fa-solid fa-trash"></i></td>
          </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    </div>

  </div>

</div>

<div class="row mt-5 mb-5">

  <div class="col-12">
    <div class="d-flex">
        <h2 class="text-center">Categorias</h2>
        <button class="btn btn-cdx ms-auto me-0" data-bs-toggle="modal" data-bs-target="#newDrinkModal"><span>Nova</span></button>
    </div>
    <div class="table-responsive mt-4">
    <small class="float-end" style="color: #DCDC">Categorias cadastradas: <?php echo e(count($categories)); ?></small>
      <table class="table table-light table-striped align-middle">
        <thead class="table-dark">
          <tr>
            <th scope="col" width="85%">Categoria</th>
            <th scope="col" width="15%" colspan="2">Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($category->category); ?></td>
            <td><button class="btn-update"><i class="fa-solid fa-pen"></i></button></td>
            <td><i class="fa-solid fa-trash"></i></td>
          </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

<!-- Modal new drink-->
<div class="modal fade" id="newDrinkModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="newDrinkModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="/drink" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="newDrinkModalLabel">Novo Drink</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="name" class="form-label">Nome:</label>
            <input type="text" name="name" id="name" class="form-control" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Categorias:</label><br>
            <div class="form-check form-check-inline">
              <input name="categories[]" class="form-check-input" type="checkbox" id="checkboxAlcoolico" value="1" data-category="Alcoólico">
              <label class="form-check-label" for="checkboxAlcoolico">Alcoólico</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories[]" class="form-check-input" type="checkbox" id="checkboxBatido" value="2" data-category="Batido">
              <label class="form-check-label" for="checkboxBatido">Batido</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories[]" class="form-check-input" type="checkbox" id="checkboxMexido" value="3" data-category="Mexido">
              <label class="form-check-label" for="checkboxMexido">Mexido</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories[]" class="form-check-input" type="checkbox" id="checkboxMontado" value="4" data-category="Montado">
              <label class="form-check-label" for="checkboxMontado">Montado</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories[]" class="form-check-input" type="checkbox" id="checkboxNaoAlcoolico" value="5" data-category="Não Alcoólico" />
              <label class="form-check-label" for="checkboxNaoAlcoolico">Não Alcoólico</label>
            </div>
          </div>

          <div class="mb-3 row">
            <div class="col mt-3 mt-lg-0">
              <label class="form-label">Ingredientes:</label>
              <textarea name="ingredients" id="ingredients" class="form-control" rows="5"></textarea>
              <small>Não se esqueça de seguir o padrão: quantidade + ingrediente. ex: 30ml de vodka</small>
            </div>
            <div class="mb-3 mt-5">
              <label for="preparation" class="form-label">Modo de Preparo:</label>
              <textarea type="hidden" name="preparation" id="preparation" class="form-control" rows="7"></textarea>
              <small>Não se esqueça de colocar cada passo em uma linha</small>
            </div>
          </div>

          <div class="mb-3">
            <label for="photo" class="form-label">Imagem ilustração:</label>
            <img style="max-width: 128px; max-height: 128px; display: block;" src="/images/boxed-bg.jpg">
            <input type="file" name="photo" id="photo" class="form-control mt-2" accept="image/*">
            <small>A imagem deve ser quadrada e tamanho máximo 500mb</small>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-cdx-light ms-0 me-auto" data-bs-dismiss="modal"><span>Fechar</span></button>
          <button type="submit" class="btn btn-cdx"><span>Salvar</span></button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal update drink -->
<div class="modal fade" id="updateDrinkModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="updateDrinkModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="/drinks" method="POST">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="updateDrinkModalLabel">Editar Drink</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="_id" id="idUpdate">
          <div class="mb-3">
            <label for="name" class="form-label">Nome:</label>
            <input type="text" name="name" id="nameUpdate" class="form-control" value="" required />
          </div>
          <div class="mb-3">
            <label class="form-label">Categorias:</label><br>
            <div class="form-check form-check-inline">
              <input name="categories-update" class="form-check-input" type="checkbox" id="checkboxAlcoolicoUpdate" value="Alcoólico" data-category="Alcoólico" />
              <label class="form-check-label" for="checkboxAlcoolico">Alcoólico</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories-update" class="form-check-input" type="checkbox" id="checkboxBatidoUpdate" value="Batido" data-category="Batido" />
              <label class="form-check-label" for="checkboxBatido">Batido</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories-update" class="form-check-input" type="checkbox" id="checkboxMexidoUpdate" value="Mexido" data-category="Mexido" />
              <label class="form-check-label" for="checkboxMexido">Mexido</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories-update" class="form-check-input" type="checkbox" id="checkboxMontadoUpdate" value="Montado" data-category="Montado" />
              <label class="form-check-label" for="checkboxMontado">Montado</label>
            </div>
            <div class="form-check form-check-inline">
              <input name="categories-update" class="form-check-input" type="checkbox" id="checkboxNaoAlcoolicoUpdate" value="Não alcoólico" data-category="Não Alcoólico" />
              <label class="form-check-label" for="checkboxNaoAlcoolico">Não Alcoólico</label>
            </div>
          </div>

          <div class="mb-3 row">
            <div class="col-lg-6 mt-3 mt-lg-0">
              <label class="form-label">Ingredientes:</label>
              <textarea name="ingredientsList" id="ingredientsListUpdate" class="form-control" rows="5">⚬ </textarea>
            </div>
          </div>

          <div class="mb-3 mt-5">
            <label for="preparation" class="form-label">Modo de Preparo:</label>
            <textarea name="stepsList" id="stepsListUpdate" rows="7" class="form-control">⚬ </textarea>
          </div>

          <div class="mt-5 mb-3">
            <label for="photoUpdate" class="form-label">Imagem ilustração:</label>
            <img style="max-width: 128px; max-height: 128px; display: block;" src="/images/boxed-bg.jpg">
            <input type="file" name="photo" id="photoUpdate" class="form-control mt-2" accept="image/*">
            <small>A imagem deve ser quadrada e tamanho máximo 500mb</small>
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-cdx-light ms-0 me-auto" data-bs-dismiss="modal"><span>Fechar</span></button>
          <button type="submit" class="btn btn-cdx"><span>Salvar</span></button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal delete drink -->
<div class="modal fade" id="deleteDrinkModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="deleteDrinkModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5">Deletar drink</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="text-center" id="deleteDrinkText"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-cdx-light ms-0 me-auto" data-bs-dismiss="modal"><span>Não</span></button>
        <form id="deleteDrinkFrom">
          <input type="hidden" name="id" id="deleteDrinkId" />
          <button type="submit" class="btn btn-cdx"><span>Sim</span></button>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="/js/codxfilereader.js"></script>

<script>
  // PREVIEW DA IMAGEM SELECIONADA
  new CODXFileReader("#newDrinkModal [type=file]", "#newDrinkModal img")
  new CODXFileReader("#updateDrinkModal [type=file]", "#updateDrinkModal img");

  // CHAMANDO MODAL DELETE DRINK
  function deleteDrink(id, name) {
    let modalDelete = new bootstrap.Modal(document.querySelector("#deleteDrinkModal"))
    document.querySelector('#deleteDrinkId').value = id
    document.querySelector('#deleteDrinkText').innerHTML = `Tem certeza que deseja deletar o drink: <br> <b>${name}<b>?`
    modalDelete.show()
  }

  // RECUPERANDO O FORM DO MODAL DELETE DRINK
  let formDelete = document.querySelector("#deleteDrinkModal form")

  formDelete.addEventListener("submit", e => {

    e.preventDefault()

    let id = document.querySelector("#deleteDrinkId").value
    fetch(`/drinks/${id}`, {
        method: 'DELETE',
      })
      .then(response => response.json())
      .then(json => {

        window.location.reload()

      }).catch(err => {

        console.log(err)

      })

  })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/thedrinks/resources/views//admin/index.blade.php ENDPATH**/ ?>