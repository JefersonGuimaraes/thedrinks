<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>The Drinks</title>
</head>
<body>
  <h1><?php echo e($title); ?></h1>
  <h2><?php echo e($language); ?></h2>
  <!-- Teste -->
</body>
</html><?php /**PATH /var/www/html/thedrinks/resources/views/drinks.blade.php ENDPATH**/ ?>