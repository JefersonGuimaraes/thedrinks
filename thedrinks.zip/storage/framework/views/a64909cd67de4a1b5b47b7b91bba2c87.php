<?php $__env->startSection('title', 'Drink | The Drink'); ?>

<?php $__env->startSection('content'); ?>
<div class="row mt-5 pb-3">
  <div class="col-lg-5 d-flex">
    <div class="mx-auto">
      <img src="/images/drinks/<?php echo e($drink->photo); ?>" alt="<?php echo e($drink->name); ?>" class="mx-auto my-auto img-fluid" style="border-radius: 20px; max-height: 600px">
      <p class="text-end mt-4" style="color: #DCDC; font-size: .875em">Visualizações: <?php echo e($drink->views); ?></p>
    </div>
  </div>
  <div class="col-lg-7 ps-lg-3">
    <h1 class="text-center mt-4 mt-lg-0"><?php echo e($drink->name); ?></h1>
    <div class="row">
      <div class="col-md-6">
        <h2 class="fs-4 mt-5">Categorias:</h2>
        <ul>
          <?php $__currentLoopData = $drink->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($category->category); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <div class="col-md-6">
        <h2 class="fs-4 mt-5">Ingredientes:</h2>
        <ul class="mt-3">
          <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($ingredient != null): ?>
            <li class="mt-2"><?php echo e($ingredient); ?></li>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    </div>
    <h2 class="fs-4 mt-5">Modo de preparo:</h2>
    <ol class="mt-3">
      <?php $__currentLoopData = $preparation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($step != null): ?>
        <li class="mt-2"><?php echo e($step); ?></li>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
  </div>
</div>
<div class="divisor"></div>    
<section class="categories" id="related">
  <h2>Drinks que pode gostar</h2>
  <div class="row mt-5 mb-5">
    <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3 col-lg-4 mb-4">
        <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
          <div class=" card">
            <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->photo); ?>">
            <div class="card-body">
              <h3 class="card-title"><?php echo e($drink->name); ?></h3>
            </div>
          </div>
        </a>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/thedrinks/resources/views/drink/drink.blade.php ENDPATH**/ ?>