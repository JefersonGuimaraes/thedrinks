<?php $__env->startSection('title', 'Drink | The Drink'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="text-center">Drink com id: <?php echo e($id); ?></h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/thedrinks/resources/views/drink.blade.php ENDPATH**/ ?>