<?php $__env->startSection('title', 'The Drinks'); ?>

<?php $__env->startSection('content'); ?>

<section class="categories" id="mostWanted">
  <h2>Drinks <?php echo e($title); ?>:</h2>
  <div class="row mt-5 mb-5">
    <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-lg-4 mt-4">
      <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
        <div class=" card">
          <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->photo); ?>">
          <div class="card-body">
            <h3 class="card-title"><?php echo e($drink->name); ?></h3>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/thedrinks/resources/views/drink/drinks.blade.php ENDPATH**/ ?>