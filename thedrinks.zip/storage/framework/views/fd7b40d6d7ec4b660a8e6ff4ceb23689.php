<?php $__env->startSection('title', 'The Drinks'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="mt-5">The Drinks</h1>

<p class="mt-3">
  Aqui você encontra as melhores receitas para fazer aquele drink incrível. Não importa se você está planejando
  uma festa, desejando relaxar após um longo dia ou apenas querendo explorar novos horizontes de sabor, nosso site
  de receitas de bebidas é seu guia definitivo. De margaritas a martinis, de smoothies a shots, estamos aqui para
  tornar suas experiências de degustação verdadeiramente inesquecíveis.
</p>

<div class="divisor"></div>

<?php if($search): ?>
  <section class="categories" id="search">
    <h2>Buscado por: <?php echo e($search); ?></h2>
    <div class="row mt-5 mb-5">
      <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3 col-lg-4 mb-4">
        <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
          <div class=" card">
            <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->photo); ?>">
            <div class="card-body">
              <h3 class="card-title"><?php echo e($drink->name); ?></h3>
            </div>
          </div>
        </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>

<div class="divisor"></div>
<?php endif; ?>

<section class="categories" id="mostWanted">
  <h2>Drinks mais procurados</h2>
  <div class="row mt-5 mb-5">
    <?php $__currentLoopData = $mostWanted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-lg-4 mb-4">
      <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
        <div class=" card">
          <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->photo); ?>">
          <div class="card-body">
            <h3 class="card-title"><?php echo e($drink->name); ?></h3>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</section>

<div class="divisor"></div>

<section class="categories" id="alcoholics">
  <h2>Alcoólicos</h2>
  <div class="row mt-5 mb-5 align-items-stretch">
    <?php $__currentLoopData = $alcoholics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-lg-4 mb-4">
      <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
        <div class="card">
          <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->name); ?>">
          <div class="card-body">
            <h3 class="card-title"><?php echo e($drink->name); ?></h3>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="d-flex">
    <a href="/drinks/1" class="mx-auto seeMore">Ver mais <i class="fa-solid fa-caret-down"></i></a>
  </div>
</section>

<div class="divisor"></div>

<section class="categories" id="notAlcoholics">
  <h2>Sem Álcool</h2>
  <div class="row mt-5 mb-5">
    <?php $__currentLoopData = $notAlcoholics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-lg-4 mb-4">
      <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
        <div class="card">
          <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->name); ?>">
          <div class="card-body">
            <h3 class="card-title"><?php echo e($drink->name); ?></h3>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="d-flex">
    <a href="/drinks/5" class="mx-auto seeMore">Ver mais <i class="fa-solid fa-caret-down"></i></a>
  </div>
</section>

<div class="divisor"></div>

<section class="categories" id="scrambled">
  <h2>Mexidos</h2>
  <div class="row mt-5 mb-5">
    <?php $__currentLoopData = $scrambled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-lg-4 mb-4">
      <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
        <div class="card">
          <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->name); ?>">
          <div class="card-body">
            <h3 class="card-title"><?php echo e($drink->name); ?></h3>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="d-flex">
    <a href="/drinks/3" class="mx-auto seeMore">Ver mais <i class="fa-solid fa-caret-down"></i></a>
  </div>
</section>

<div class="divisor"></div>

<section class="categories" id="assembled">
  <h2>Montados</h2>
  <div class="row mt-5 mb-5">
    <?php $__currentLoopData = $assembled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-lg-4 mb-4">
      <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
        <div class="card">
          <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->name); ?>">
          <div class="card-body">
            <h3 class="card-title"><?php echo e($drink->name); ?></h3>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="d-flex">
    <a href="/drinks/4" class="mx-auto seeMore">Ver mais <i class="fa-solid fa-caret-down"></i></a>
  </div>
</section>

<div class="divisor"></div>

<section class="categories" id="shaken">
  <h2>Batidos</h2>
  <div class="row mt-5 mb-5">
    <?php $__currentLoopData = $shaken; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 col-lg-4 mb-4">
      <a href="/drink/<?php echo e($drink->id); ?>" class="linkDrink">
        <div class="card">
          <img src="/images/drinks/<?php echo e($drink->photo); ?>" class="card-img-top" alt="<?php echo e($drink->name); ?>">
          <div class="card-body">
            <h3 class="card-title"><?php echo e($drink->name); ?></h3>
          </div>
        </div>
      </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="d-flex">
    <a href="/drinks/3" class="mx-auto seeMore">Ver mais <i class="fa-solid fa-caret-down"></i></a>
  </div>
</section>

<script>
  window.onscroll = function() {
    progressBar()
  };

  function progressBar() {
    var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
    var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    var scrolled = (winScroll / height) * 100;
    document.getElementById("progress-bar").style.width = scrolled + "%";
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/thedrinks/resources/views/home.blade.php ENDPATH**/ ?>